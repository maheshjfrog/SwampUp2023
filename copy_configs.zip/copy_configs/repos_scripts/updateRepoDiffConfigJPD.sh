#! /bin/bash

### Exit the script on any failures
set -eo pipefail
set -e
set -u

### Get Arguments
FILE_NAME="${1:?please provide the file name to parse. ex - diffFile.txt}"
SOURCE_JPD_URL="${2:?please enter JPD URL. ex - https://ramkannan.jfrog.io}"
TARGET_JPD_URL="${3:?please enter JPD URL. ex - http://35.209.109.173:8082}"
USER_NAME="${4:?please provide the username in JPD . ex - admin}"
AUTH_TOKEN_JPD_1="${5:?please provide the user identity token for source}"
METHOD="${6:?please provide method to perform . ex - PUT to create or POST for update}"
AUTH_TOKEN_JPD_2="${7:?please provide the user identity token for target}"
performDelete=false

rm -rf *.json

### parse file
while IFS= read -r line; do
    if [[ $line == *"+"* ]]; then
        repoadd=$(echo $line | cut -d "+" -f2 | xargs)
        echo -e "\nAdd Repo ==> $repoadd"
        echo -e "Exporting JSON for $repoadd from $SOURCE_JPD_URL"
        curl -X GET -u "${USER_NAME}":"${AUTH_TOKEN_JPD_1}" "$SOURCE_JPD_URL/artifactory/api/repositories/$repoadd" -s > "$repoadd.json"

        projectkey=$(cat "$repoadd.json" | jq .projectKey | xargs)
        echo "Project Key = $projectkey"
        if [[ "$projectkey" == "null" ]]; then
            echo -e "Importing JSON $repoadd.json to $TARGET_JPD_URL"
            if [[ $METHOD == "create" ]]; then
                curl -X PUT -u "${USER_NAME}":"${AUTH_TOKEN_JPD_2}" "$TARGET_JPD_URL/artifactory/api/repositories/$repoadd" -d @"$repoadd.json" -s -H 'Content-Type: application/json'
            elif [[ $METHOD == "update" ]]; then
                curl -X POST -u "${USER_NAME}":"${AUTH_TOKEN_JPD_2}" "$TARGET_JPD_URL/artifactory/api/repositories/$repoadd" -d @"$repoadd.json" -s -H 'Content-Type: application/json'
            else 
                echo -e "\nInvalid Method given in arguments"
            fi
        else 
            echo "Project Key $projectkey is present in $repoadd"
            cat "$repoadd.json" | jq '.projectKey = ""' > "updated_$repoadd.json"
            echo -e "Importing JSON $repoadd.json to $TARGET_JPD_URL"
            if [[ $METHOD == "create" ]]; then
                curl -X PUT -u "${USER_NAME}":"${AUTH_TOKEN_JPD_2}" "$TARGET_JPD_URL/artifactory/api/repositories/$repoadd" -d @"updated_$repoadd.json" -s -H 'Content-Type: application/json'
            elif [[ $METHOD == "update" ]]; then
                curl -X POST -u "${USER_NAME}":"${AUTH_TOKEN_JPD_2}" "$TARGET_JPD_URL/artifactory/api/repositories/$repoadd" -d @"$repoadd.json" -s -H 'Content-Type: application/json'
            else
                echo -e "\nInvalid Method given in arguments"
            fi
            echo -e "Move $repoadd to $projectkey in $TARGET_JPD_URL"
            curl --location --request PUT "$TARGET_JPD_URL/access/api/v1/projects/_/attach/repositories/$repoadd/$projectkey" --header "Authorization: Bearer $AUTH_TOKEN_JPD_2"
            echo -e "Completed $METHOD of $repoadd !!\n\n"
            sleep 5
        fi
        echo -e "\n"
    elif [[ $line == *"-"* ]]; then
        repodelete=$(echo $line | cut -d "-" -f2- | xargs)
        if [ $performDelete == "true" ]; then
            echo -e "\nDelete Repo ==> $repodelete"
            curl -X DELETE -u "${USER_NAME}":"${AUTH_TOKEN_JPD_2}" "$TARGET_JPD_URL/artifactory/api/repositories/$repodelete"
        else
            echo -e "\nSkipping Delete as Deletion is set to $performDelete"
        fi
    else 
        echo -e "\nInvalid Input"
    fi
done < $FILE_NAME

### sample cmd to run - ./updateRepoDiffConfigJPD.sh diffFile.txt https://ramkannan.jfrog.io http://35.209.109.173:8082 admin **** create/update ****