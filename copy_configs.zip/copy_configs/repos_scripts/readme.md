How to view  repository permissions with REST API?

You can use the api/artifactpermissions  Internal End Point with repoKey parameter. You could use the jq to see the well structured result.
See KB [How to view repository permissions with REST API?](https://jfrog.com/help/r/artifactory-how-to-view-repository-permissions-with-rest-api)

```
curl -u admin 'https://ART_URL/artifactory/api/artifactpermissions?repoKey=<repo_key>' | jq

```

---

